"""
Project: ProdaptNLService
Author: Abishek KJ
Date: 25-May-2021
"""

DB_USER = "user_abishek"
DB_PASSWORD = "Abishek27"
POSTS_URL = "https://jsonplaceholder.typicode.com/posts"
COMMENTS_URL = "https://jsonplaceholder.typicode.com/comments"

